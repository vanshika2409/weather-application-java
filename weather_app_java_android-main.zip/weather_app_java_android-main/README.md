# weather_app_java_android

Functionalities:

•Location based weather •Weather condition of any city

Technology :

•Java •XML •API

Description :

A Java application which is used to find weather conditions.
